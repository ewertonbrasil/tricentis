#encoding utf-8
require 'selenium-webdriver'
require 'rspec/expectations'
include RSpec::Matchers


Dado('que quero acessar site da tricents') do
    visit "http://sampleapp.tricentis.com/101/app.php"

end
  
Quando('preencho o formulario') do
 
  # sleep 5
  ##find("#make").click 
   sleep 5
   find("#make").find('option', text: "BMW").select_option
   sleep 10
   find("#model").find('option', text: "Scooter").select_option
   sleep 10
   find("#cylindercapacity").set "100"
   sleep 15
   find("#engineperformance").set "1000"
   sleep 5
   find("#dateofmanufacture").set "05/01/2021"
   sleep 5
   find("#numberofseats").find('option', text: "2").select_option
   sleep 5

     
  #find("#righthanddriveyes input[type=radio]", visible: false).click
  
  # sleep 5
   
   find("#numberofseatsmotorcycle").find('option', text: "1").select_option
   sleep 5 
   find("#fuel").find('option', text: "Electric Power").select_option
   sleep 5  
   find("#payload").set "15" 
   sleep 5
   find("#totalweight").set "220" 
   sleep 5 
   find("#listprice").set "580" 
   sleep 5 
   find("#licenseplatenumber").set "580" 
   sleep 5 
   find("#annualmileage").set "700" 
   sleep 5 

   click_button "Next"
   sleep 20

   find("#firstname").set "Joao" 
   sleep 5
   find("#lastname").set "Silva" 
   sleep 5
   find("#birthdate").set "05/01/1990" 
   sleep 5
   
    #find("#gendermale input[type=radio]", visible: false).click
    #sleep 5
   
   find("#country").find('option', text: "Brazil").select_option 
   sleep 5
   find("#zipcode").set "58400000" 
   sleep 5
   find("#occupation").find('option', text: "Farmer").select_option 
   sleep 5
    #find("#speeding input[type=checkbox]", visible: false).click
    #sleep 5


   click_button "Next"
   sleep 20 

   find("#startdate").set "11/21/2021" 
   sleep 6
   find("#insurancesum").find('option', text: "3.000.000,00").select_option 
   sleep 6
   find("#meritrating").find('option', text: "Bonus 1").select_option 
   sleep 5
   find("#damageinsurance").find('option', text: "Full Coverage").select_option 
   sleep 5
   #find("#EuroProtection input[type=checkbox]", visible: false).click
   #sleep 5
   find("#courtesycar").find('option', text: "Yes").select_option 
   sleep 5
   
   click_button "Next"
   sleep 20 

   #find("#selectsilver input[type=radio]", visible: false).click
   #sleep 5 

   click_button "Next"
   sleep 20 

   find("#email").set "eb@gmail.com" 
   sleep 5
   find("#username").set "ebrasil" 
   sleep 5
   find("#password").set "Abcd1234" 
   sleep 5
   find("#confirmpassword").set "Abcd1234" 
   sleep 5

   click_button "Send"
   sleep 20 


end
  
Entao('email enviado') do
    sleep 5
    expect(page).to have_text("Sending e-mail success!", minimum: 1)
    sleep 5

end